import React from 'react';
import { PWAInstallButton } from './PWAInstallButton';

export const Header: React.FC = () => {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 py-3">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        {/* Brand with Ultra-Premium App Store Icon */}
        <div className="flex items-center gap-3">
          <div className="relative group">
            <div className="w-10 h-10 rounded-2xl p-0.5 bg-gradient-to-tr from-blue-700 via-indigo-600 to-sky-400 shadow-md shadow-blue-600/25 flex items-center justify-center transition-transform active:scale-95">
              <img
                src="./icon.svg"
                alt="Dosya Dönüştürücü Logo"
                className="w-full h-full rounded-[14px] object-cover"
              />
            </div>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-slate-900 text-base sm:text-lg leading-tight tracking-tight">
                Dosya <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">Dönüştürücü</span>
              </h1>
              <span className="inline-flex items-center px-1.5 py-0.5 rounded-md text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-amber-600 text-white shadow-xs">
                PRO
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">
              Çevrimdışı Belge & Fotoğraf İşleme
            </span>
          </div>
        </div>

        {/* Right actions: Source Zip Download & PWA Install */}
        <div className="flex items-center gap-2">
          <a
            href="./dosya-donusturucu-github.zip"
            download="dosya-donusturucu-github.zip"
            title="GitHub için hazır proje ZIP arşivini indir"
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-200 transition-colors shadow-xs active:scale-95"
          >
            <svg className="w-4 h-4 text-slate-700" fill="currentColor" viewBox="0 0 24 24">
              <path fillRule="evenodd" clipRule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.53 1.032 1.53 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" />
            </svg>
            <span>GitHub ZIP</span>
          </a>
          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
};
